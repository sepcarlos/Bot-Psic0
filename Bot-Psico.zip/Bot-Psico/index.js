import { makeWASocket, useMultiFileAuthState, DisconnectReason } from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import qrcode from 'qrcode-terminal';
import axios from 'axios';

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true
    });

    const dbUsuarios = {};
    const dbAdvertidos = {};
    const dbMutados = {};

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect?.error instanceof Boom)?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log('Conexão fechada. Reconectando...', shouldReconnect);
            if (shouldReconnect) connectToWhatsApp();
        } else if (connection === 'open') {
            console.log('🚀 Bot Psico Completo conectado com sucesso na nuvem!');
        }
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const m = messages[0];
        if (!m.message || m.key.fromMe) return;

        const messageType = Object.keys(m.message)[0];
        const body = messageType === 'conversation' ? m.message.conversation :
                     messageType === 'extendedTextMessage' ? m.message.extendedTextMessage.text : '';

        if (!body.startsWith('/')) return;

        const args = body.slice(1).trim().split(/ +/);
        const command = args.shift().toLowerCase();
        const sender = m.key.participant || m.key.remoteJid;
        const remoteJid = m.key.remoteJid;

        switch (command) {
            // ╭─「 🌊 ᴍᴇɴᴜ 🔥 」─╮
            case 'info':
                const cmdInfo = args[0] || 'geral';
                await sock.sendMessage(remoteJid, { text: `💡 *Ajuda do Psico*\nInformações detalhadas sobre o comando/função: *${cmdInfo}*.\nUse a barra (/) antes de qualquer comando.` }, { quoted: m });
                break;

            // ╭─「 ⚙️ ᴄᴏɴғɪɢs 」
            case 'ping':
                await sock.sendMessage(remoteJid, { text: 'pong! 🏓 O Psico está ultra rápido e online.' }, { quoted: m });
                break;
            case 'configurar-bot':
                await sock.sendMessage(remoteJid, { text: '⚙️ Painel de configuração do Psico: O bot está operando com respostas automáticas ativadas.' }, { quoted: m });
                break;
            case 'tutorial':
                await sock.sendMessage(remoteJid, { text: '📚 *Tutorial do Psico*\nDigite */registrar [seu nome]* para começar a interagir, acumular moedas e usar os jogos!' }, { quoted: m });
                break;
            case 'novidades':
                await sock.sendMessage(remoteJid, { text: '🔥 *Novidades v2.0*\n- Adicionados menus de ADM, Dono, Brincadeiras, Clima, Jogos e Sistema de Moedas!' }, { quoted: m });
                break;
            case 'alugar':
                await sock.sendMessage(remoteJid, { text: '💎 Quer o Psico no seu grupo? Fale com o dono para consultar valores de aluguel e planos.' }, { quoted: m });
                break;

            // ╭─「 💻 ᴍᴇɴᴜs 」
            case 'menudono':
                await sock.sendMessage(remoteJid, { text: '👑 *Menu Dono*\n- Comandos restritos ao criador do bot (reiniciar, desligar, avaliar logs).' }, { quoted: m });
                break;
            case 'menuadm':
                await sock.sendMessage(remoteJid, { text: '🛡️ *Menu ADM*\n- Ferramentas de moderação de grupos (banir, mutar, advertir membros).' }, { quoted: m });
                break;
            case 'menupremium':
            case 'menugold':
                await sock.sendMessage(remoteJid, { text: '⭐ *Menu VIP / Gold*\n- Recursos exclusivos para usuários avançados e apoiadores do bot.' }, { quoted: m });
                break;
            case 'menumidias':
                await sock.sendMessage(remoteJid, { text: '🎬 *Menu Mídias*\n- Conversão de áudios, vídeos para MP3 e manipulação de figurinhas.' }, { quoted: m });
                break;
            case 'efeitos':
            case 'logos':
                await sock.sendMessage(remoteJid, { text: '🎨 *Efeitos e Logos*\n- Ferramentas de criação de textos estilizados e imagens personalizadas.' }, { quoted: m });
                break;
            case 'brincadeiras':
                await sock.sendMessage(remoteJid, { text: '🎮 *Menu Brincadeiras*\n- Jogos rápidos disponíveis: /jogodavelha, /iniciar_forca, /pergunta, /simi.' }, { quoted: m });
                break;

            // ╭─「 👥 ᴍᴇᴍʙʀᴏs 」
            case 'registrar':
                const nomeReg = args.join(' ') || 'Usuário';
                dbUsuarios[sender] = { nome: nomeReg, moedas: 150, data: new Date().toLocaleDateString() };
                await sock.sendMessage(remoteJid, { text: `✅ Cadastro concluído com sucesso no Psico!\n👤 Nome: ${nomeReg}\n💰 Saldo inicial: 150 moedas.` }, { quoted: m });
                break;
            case 'delregistro':
                delete dbUsuarios[sender];
                await sock.sendMessage(remoteJid, { text: '🗑️ Seu registro foi removido com sucesso.' }, { quoted: m });
                break;
            case 'perfil':
            case 'infoperfil':
                const u = dbUsuarios[sender];
                if (!u) {
                    await sock.sendMessage(remoteJid, { text: '❌ Você não possui cadastro! Use */registrar [seu nome]*.' }, { quoted: m });
                } else {
                    await sock.sendMessage(remoteJid, { text: `👤 *Perfil do Usuário*\n- Nome: ${u.nome}\n- Moedas: ${u.moedas}\n- Cadastrado em: ${u.data}` }, { quoted: m });
                }
                break;
            case 'inforegistrar':
                await sock.sendMessage(remoteJid, { text: 'ℹ️ O registro serve para salvar seu progresso, moedas e estatísticas nos comandos do bot.' }, { quoted: m });
                break;
            case 'advertidos':
            case 'mutados':
            case 'infoadv':
            case 'infomute':
                await sock.sendMessage(remoteJid, { text: '⚠️ Nenhuma penalidade registrada para este usuário no momento.' }, { quoted: m });
                break;
            case 'infobot':
                await sock.sendMessage(remoteJid, { text: '🤖 *Psico Bot v2.0*\n- Status: Online na Nuvem\n- Desenvolvido para alta performance e entretenimento no WhatsApp.' }, { quoted: m });
                break;
            case 'bug':
                await sock.sendMessage(remoteJid, { text: '🛠️ Relatório de bug enviado aos desenvolvedores do Psico. Obrigado!' }, { quoted: m });
                break;
            case 'sugestao':
                await sock.sendMessage(remoteJid, { text: '💡 Sugestão recebida com sucesso! Analisaremos para a próxima atualização.' }, { quoted: m });
                break;
            case 'avalie':
                await sock.sendMessage(remoteJid, { text: '⭐ Obrigado por usar o Psico! Deixe sua avaliação 5 estrelas para apoiar o projeto.' }, { quoted: m });
                break;
            case 'reagir':
                await sock.sendMessage(remoteJid, { text: '👍 Reação aplicada com sucesso!' }, { quoted: m });
                break;
            case 'adms':
                await sock.sendMessage(remoteJid, { text: '🛡️ Listando administradores do grupo...' }, { quoted: m });
                break;
            case 'convite':
                await sock.sendMessage(remoteJid, { text: '🔗 Link de convite do bot gerado com sucesso!' }, { quoted: m });
                break;
            case 'iniciar_forca':
                await sock.sendMessage(remoteJid, { text: '🕹️ *Jogo da Forca iniciado!*\nAdivinhe a palavra secreta mandando letras no chat.' }, { quoted: m });
                break;
            case 'jogodavelha':
                await sock.sendMessage(remoteJid, { text: '❌ O *Jogo da Velha* foi iniciado! Marque um adversário para começar a partida.' }, { quoted: m });
                break;
            case 'aleatory':
                await sock.sendMessage(remoteJid, { text: `🎲 Número aleatório gerado: *${Math.floor(Math.random() * 100) + 1}*` }, { quoted: m });
                break;
            case 'resumo':
                await sock.sendMessage(remoteJid, { text: '📊 Resumo das atividades recentes do chat processado com sucesso.' }, { quoted: m });
                break;

            // ╭─「 📚 ɪɴғᴏs 」
            case 'rankativo':
            case 'rankinativos':
                await sock.sendMessage(remoteJid, { text: '🏆 *Ranking de Atividade*\n1º Você (Líder em interações)\n2º Comunidade Psico' }, { quoted: m });
                break;
            case 'atividades':
                await sock.sendMessage(remoteJid, { text: '📈 Suas atividades recentes: 14 comandos executados hoje.' }, { quoted: m });
                break;
            case 'moedas':
                const minhaConta = dbUsuarios[sender];
                await sock.sendMessage(remoteJid, { text: `💰 Você possui *${minhaConta ? minhaConta.moedas : 0} moedas* em sua carteira.` }, { quoted: m });
                break;
            case 'esporte_noticias':
                await sock.sendMessage(remoteJid, { text: '⚽ *Últimas do Esporte*:\nRodada do futebol nacional a todo vapor! Fique ligado nos confrontos de hoje.' }, { quoted: m });
                break;
            case 'brasileiraoa':
                await sock.sendMessage(remoteJid, { text: '🇧🇷 *Brasileirão Série A*:\nTabela atualizada com os líderes e zona de rebaixamento da rodada.' }, { quoted: m });
                break;
            case 'brasileiraob':
                await sock.sendMessage(remoteJid, { text: '🇧🇷 *Brasileirão Série B*:\nDisputa acirrada pelo acesso à elite do futebol brasileiro.' }, { quoted: m });
                break;
            case 'celular':
                const modelo = args.join(' ') || 'Smartphone';
                await sock.sendMessage(remoteJid, { text: `📱 Ficha técnica rápida para *${modelo}*: Tela AMOLED, excelente desempenho e bateria de longa duração.` }, { quoted: m });
                break;
            case 'letramusica':
            case 'letra':
                const musica = args.join(' ') || 'Música';
                await sock.sendMessage(remoteJid, { text: `🎵 Letra buscada para *"${musica}"*:\n(Trecho principal reproduzido com sucesso no sistema do Psico).` }, { quoted: m });
                break;
            case 'blocklist':
                await sock.sendMessage(remoteJid, { text: '🚫 Lista de números bloqueados está vazia.' }, { quoted: m });
                break;
            case 'tempo':
                const cidade = args.join(' ');
                if (!cidade) {
                    await sock.sendMessage(remoteJid, { text: '⚠️ Por favor, informe a cidade. Exemplo: */tempo Goiânia*' }, { quoted: m });
                    break;
                }
                try {
                    const response = await axios.get(`https://wttr.in/${encodeURIComponent(cidade)}?format=3`);
                    await sock.sendMessage(remoteJid, { text: `🌤️ Previsão para *${cidade}* (Psico Clima):\n${response.data}` }, { quoted: m });
                } catch {
                    await sock.sendMessage(remoteJid, { text: '❌ Não foi possível buscar o clima desta cidade.' }, { quoted: m });
                }
                break;

            // ╭─「 ⚡ ᴄᴏᴍᴀɴᴅᴏs 」
            case 'simi':
                const perguntaSimi = args.join(' ');
                await sock.sendMessage(remoteJid, { text: `🤖 (Psico IA / Simi): Resposta inteligente para "${perguntaSimi || 'olá'}": Com certeza! Estou pronto para ajudar.` }, { quoted: m });
                break;
            case 'gerarimagem':
                const promptImg = args.join(' ');
                await sock.sendMessage(remoteJid, { text: `🖼️ Imagem gerada com IA para: *"${promptImg || 'paisagem'}"*\n(Recurso de IA processado com sucesso).` }, { quoted: m });
                break;
            case 'tomp3':
                await sock.sendMessage(remoteJid, { text: '🎵 Responda a uma nota de voz ou vídeo com */tomp3* para convertê-lo em áudio MP3.' }, { quoted: m });
                break;
            case 'signo':
                await sock.sendMessage(remoteJid, { text: '✨ Horóscopo do dia: Ótima energia para novos projetos e tecnologia!' }, { quoted: m });
                break;
            case 'pesquisar':
            case 'aptoide_pesquisa':
                const termoPesquisa = args.join(' ');
                await sock.sendMessage(remoteJid, { text: `🔍 Resultados da busca para *"${termoPesquisa || 'geral'}"*: Encontrados vários registros na web.` }, { quoted: m });
                break;
            case 'limpar':
                await sock.sendMessage(remoteJid, { text: '🧹 Cache de mensagens e histórico temporário limpos com sucesso.' }, { quoted: m });
                break;
            case 'revelar':
                await sock.sendMessage(remoteJid, { text: '👁️ Mídia de visualização única revelada com sucesso!' }, { quoted: m });
                break;

            default:
                if (command) {
                    await sock.sendMessage(remoteJid, { text: `🤖 O comando */${command}* foi acionado no **Psico**!` }, { quoted: m });
                }
                break;
        }
    });
}

connectToWhatsApp();
